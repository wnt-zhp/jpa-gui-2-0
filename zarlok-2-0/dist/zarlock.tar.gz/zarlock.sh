#!/bin/bash

java -cp "zarlock.jar:lib/*" -splash:splash.bmp cx.ath.jbzdak.zarlok.main.AppLauncher
